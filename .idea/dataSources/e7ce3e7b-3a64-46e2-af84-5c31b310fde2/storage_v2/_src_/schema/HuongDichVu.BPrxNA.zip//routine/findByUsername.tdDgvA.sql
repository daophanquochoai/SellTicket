create
    definer = root@`%` procedure findByUsername(IN user_param varchar(255))
begin select user_name as username, password, 1 as active from account a where user_name = user_param; end;


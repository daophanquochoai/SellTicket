create
    definer = root@`%` procedure GetActiveEmployee()
BEGIN
    SELECT * 
    FROM employee
    WHERE status = 'ACTIVE';
END;


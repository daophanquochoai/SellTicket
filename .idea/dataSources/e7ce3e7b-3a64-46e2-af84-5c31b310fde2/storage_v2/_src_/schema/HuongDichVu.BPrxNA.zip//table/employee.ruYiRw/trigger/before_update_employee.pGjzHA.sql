create definer = root@`%` trigger before_update_employee
    before update
    on employee
    for each row
BEGIN 
	IF EXISTS (SELECT 1 FROM customer c WHERE c.email = NEW.email) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Email already exists!!';
    END IF;
END;


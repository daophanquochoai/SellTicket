create definer = root@`%` trigger before_update_customer
    before update
    on customer
    for each row
begin 
	IF EXISTS (SELECT 1 FROM employee WHERE email = NEW.email) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Email already exists in employee!';
    END IF;
END;


create definer = root@`%` trigger before_insert_customer
    before insert
    on customer
    for each row
BEGIN 
	if EXISTS ( select 1 from employee e where e.email = NEW.email) THEN 
		SIGNAL SQLSTATE '45000'
		set message_text = 'Email already exists';
	end if;
END;


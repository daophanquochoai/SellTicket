create
    definer = root@`%` procedure findAuthorizationByUserName(IN user_param varchar(255))
BEGIN 
    SELECT a.user_name AS username, r.role_name AS role 
    FROM role r
    JOIN (SELECT * FROM account a WHERE a.user_name = user_param) a 
        ON a.role_id = r.id;
END;

